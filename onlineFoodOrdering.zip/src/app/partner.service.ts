import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PartnerService {
  URL = 'http://localhost:3000/partner';

  constructor(private http: HttpClient) {
  }

  // CONFIRMED ORDERS
  ConfirmOrders(data: any) {
    return this.http.post(this.URL + '/confirm-orders', data);
  }

  // PENDING ORDERS
  PendingOrders(data: any) {
    return this.http.post(this.URL + '/pending-orders', data);
  }

  // DELIVERY BOY
  ManageDeliveryBoy(data: any) {
    return this.http.post(this.URL + '/manage-delivery-boy', data);
  }

  // ITEM
  ManageItem(data: any) {
    return this.http.post(this.URL + '/manage-item', data);
  }

  // CHANGE PASSWORD
  ChangePassword(data: any) {
    return this.http.post(this.URL + '/partnerchangepassword', data);
  }

  // LOGOUT
  Logout() {
    return this.http.get(this.URL + '/partnerlogout');
  }

  // SESSION
  Session() {
    return this.http.get(this.URL + '/partnersession');
  }

  // LOGIN
  PartnerLogin(formTextData: any) {
    return this.http.post(this.URL + '/partnerlogin', formTextData);
  }

  // REGISTER
  PartnerRegister(formTextData: any) {
    return this.http.post(this.URL + '/partnersignup', formTextData);
  }
}

import {Component, OnInit} from '@angular/core';
import {AdminService} from '../admin.service';

@Component({
  selector: 'app-view-partner',
  templateUrl: './view-partner.component.html',
  styleUrls: ['./view-partner.component.css']
})
export class ViewPartnerComponent implements OnInit {
  AllPartners: any = '';
  URL = 'http://localhost:3000/';

  constructor(private adminservice: AdminService) {
  }

  ngOnInit(): void {
    // VIEW PARTNER
    this.GetAllPartners();
  }

  // ACCEPT, REJECT, BLOCK
  PartnerAction(id: any, status: any) {
    console.log(id);
    console.log(status);
    let formData = new FormData();

    if (status == 1) {
      if (confirm('Are you sure you want to Accept ?')) {
        formData.append('action', 'partner');
        formData.append('partnerid', id);
        formData.append('status', status);
        this.adminservice.PartnerAction(formData).subscribe((res: any) => {
          console.log(res);
          alert('Request Accepted.');
          this.GetAllPartners();
        });
      }
    } else if (status == 0) {
      if (confirm('Are you sure you want to Reject ?')) {
        formData.append('action', 'partner');
        formData.append('partnerid', id);
        formData.append('status', status);
        this.adminservice.PartnerAction(formData).subscribe((res: any) => {
          console.log(res);
          alert('Request Rejected.');
          this.GetAllPartners();
        });
      }
    } else {
      if (confirm('Are you sure you want to Block ?')) {
        formData.append('action', 'partner');
        formData.append('partnerid', id);
        formData.append('status', status);
        this.adminservice.PartnerAction(formData).subscribe((res: any) => {
          console.log(res);
          alert('Partner Blocked.');
          this.GetAllPartners();
        });
      }
    }
  }

  // VIEW PARTNER
  GetAllPartners() {
    let formData = new FormData();
    formData.append('action', 'getUnblockedPartner');

    this.adminservice.PartnerAction(formData).subscribe((res: any) => {
      // console.log(res);
      this.AllPartners = res;
    });
  }

}

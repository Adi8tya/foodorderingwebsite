import {Component, OnInit} from '@angular/core';
import {PartnerService} from '../partner.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-partner-header',
  templateUrl: './partner-header.component.html',
  styleUrls: ['./partner-header.component.css']
})
export class PartnerHeaderComponent implements OnInit {
  AdminName: string;

  constructor(
    private partner_service: PartnerService,
    private router: Router
  ) {
  }

  ngOnInit(): void {
    // SCROLL TO TOP
    this.ScrollToTop();

    // SESSION
    this.checkPartnerSession();
  }

  // LOGOUT
  PartnerLogout() {
    this.partner_service.Logout().subscribe((res: any) => {
      // console.log(res);

      if (res.status == 'partnerLogout') {
        this.router.navigateByUrl('partner-login');
      }
    });
  }

  // SESSION
  checkPartnerSession() {
    this.partner_service.Session().subscribe((res: any) => {
      // console.log(res);

      if (res.status == 'sessionFailed') {
        this.router.navigateByUrl('partner-login');
      } else {
        this.AdminName = res.status;
      }
    });
  }

  // SCROLL TO TOP
  ScrollToTop() {
    document.documentElement.scrollTop = 0;
  }

}

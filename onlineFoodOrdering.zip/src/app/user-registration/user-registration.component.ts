import {Component, OnInit} from '@angular/core';
import {UserService} from '../user.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-user-registration',
  templateUrl: './user-registration.component.html',
  styleUrls: ['./user-registration.component.css']
})
export class UserRegistrationComponent implements OnInit {
  Photo: any = '';
  Response: any = '';

  constructor(
    private user_service: UserService,
    private router: Router,
  ) {
  }

  ngOnInit(): void {
  }

  // REGISTER
  signupAction(formTextData: any) {
    // console.log(formTextData);
    let formData = new FormData();
    for (let i in formTextData) {
      formData.append(i, formTextData[i]);
    }
    formData.append('photo', this.Photo);

    this.user_service.UserRegister(formData).subscribe((res: any) => {
      // console.log(res);
      this.Response = res.status;

      setTimeout(() => {
        this.Response = '';
      }, 1500);

      if (res.status == 'registerSuccess') {
        (document.getElementById('registerForm') as HTMLFormElement).reset();
        setTimeout(() => {
          this.router.navigateByUrl('user-login');
        }, 2000);
      }
    });
  }

  // PHOTO
  SavePhoto(e: any) {
    // console.log(e.target.files[0]);
    this.Photo = e.target.files[0];
  }

}

import {Component, OnInit} from '@angular/core';
import {AdminService} from '../admin.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {
  AdminName: string = '';
  Message1: string = '';
  Message2: string = '';

  constructor(
    private adminservice: AdminService,
    private router: Router
  ) {
  }

  ngOnInit(): void {
  }

  // LOGIN
  loginAction(formData: any) {
    // console.log(formData);
    this.adminservice.AdminLogin(formData).subscribe((res: any) => {
      // console.log(res);

      if (res.status == 'loginFailed') {
        // (document.getElementById('loginForm') as HTMLFormElement).reset();

        this.Message1 = 'Invalid Email or Password.';
        setTimeout(() => {
          this.Message1 = '';
        }, 1500);
      } else {
        this.AdminName = res;
        (document.getElementById('loginForm') as HTMLFormElement).reset();

        this.Message2 = 'Login Success';
        setTimeout(() => {
          this.Message2 = '';
          this.router.navigateByUrl('admin-home');
        }, 1500);
      }
    });
  }

}

import {Component, OnInit} from '@angular/core';
import {PublicService} from '../public.service';

@Component({
  selector: 'app-search-partner',
  templateUrl: './search-partner.component.html',
  styleUrls: ['./search-partner.component.css']
})
export class SearchPartnerComponent implements OnInit {
  SearchedItems: any = [];
  Response: any = '';
  URL = 'http://localhost:3000/';

  constructor(private public_service: PublicService) {
  }

  ngOnInit(): void {
  }

  // SEARCH ITEM from database..
  SearchItem(data: any) {
    // console.log(data);
    let formData = new FormData();
    formData.append('action', 'searchPartner');
    formData.append('I', JSON.stringify(data));

    this.public_service.Search(formData).subscribe((res: any) => {
      // console.log(res);

      if (res.length > 0) {
        this.SearchedItems = res;
      } else {
        this.SearchedItems = '';
        this.Response = 'notfound';
        setTimeout(() => {
          this.Response = '';
        }, 1000);
      }
    });
  }

}

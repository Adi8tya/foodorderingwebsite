import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {UserService} from '../user.service';

@Component({
  selector: 'app-public-header',
  templateUrl: './public-header.component.html',
  styleUrls: ['./public-header.component.css']
})
export class PublicHeaderComponent implements OnInit {

  constructor(
    private router: Router,
    private user_Service: UserService,
  ) {
  }

  ngOnInit(): void {
    // SCROLL TO TOP
    this.ScrollToTop();

    // GET CART COUNT
    this.GetCartCount();
  }

  // GET CART COUNT
  GetCartCount() {
    let formdata = new FormData();
    formdata.append('action', 'getcartcount');

    this.user_Service.AddToCartSelectedProduct(formdata).subscribe((res: any) => {
      // console.log(res);
      (<HTMLSpanElement> document.getElementById('user-cart-count')).innerHTML = res;
    });
  }

  // VIEW CART
  ViewCart() {
    // alert('Clicked');
    this.router.navigateByUrl('view-cart');
  }

  // SCROLL TO TOP
  ScrollToTop() {
    document.documentElement.scrollTop = 0;
  }

}

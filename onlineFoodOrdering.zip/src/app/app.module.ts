import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';

import {AppRoutingModule} from './app-routing.module';
import {AppComponent} from './app.component';
import {PublicHomeComponent} from './public-home/public-home.component';
import {PublicHeaderComponent} from './public-header/public-header.component';
import {PublicFooterComponent} from './public-footer/public-footer.component';
import {HttpClientModule} from '@angular/common/http';
import {FormsModule} from '@angular/forms';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AdminHeaderComponent } from './admin-header/admin-header.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { AdminChangePasswordComponent } from './admin-change-password/admin-change-password.component';
import { ManageCategoryComponent } from './manage-category/manage-category.component';
import { ViewPartnerComponent } from './view-partner/view-partner.component';
import { ViewBlockedPartnerComponent } from './view-blocked-partner/view-blocked-partner.component';
import { ViewAllOrdersComponent } from './view-all-orders/view-all-orders.component';
import { ViewTodayOrdersComponent } from './view-today-orders/view-today-orders.component';
import { UserRegistrationComponent } from './user-registration/user-registration.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { ViewCartComponent } from './view-cart/view-cart.component';
import { UserHomeComponent } from './user-home/user-home.component';
import { UserHeaderComponent } from './user-header/user-header.component';
import { UserMyOrdersComponent } from './user-my-orders/user-my-orders.component';
import { UserChangePasswordComponent } from './user-change-password/user-change-password.component';
import { PartnerRegistrationComponent } from './partner-registration/partner-registration.component';
import { PartnerLoginComponent } from './partner-login/partner-login.component';
import { PartnerHomeComponent } from './partner-home/partner-home.component';
import { PartnerHeaderComponent } from './partner-header/partner-header.component';
import { PartnerChangePasswordComponent } from './partner-change-password/partner-change-password.component';
import { PartnerManageItemComponent } from './partner-manage-item/partner-manage-item.component';
import { PartnerDeliveryBoyComponent } from './partner-delivery-boy/partner-delivery-boy.component';
import { PartnerConfirmedOrdersComponent } from './partner-confirmed-orders/partner-confirmed-orders.component';
import { PartnerPendindOrdersComponent } from './partner-pendind-orders/partner-pendind-orders.component';
import { SearchItemComponent } from './search-item/search-item.component';
import { ThankYouComponent } from './thank-you/thank-you.component';
import { SearchPartnerComponent } from './search-partner/search-partner.component';
import { SearchPartnerDetailsComponent } from './search-partner-details/search-partner-details.component';

@NgModule({
  declarations: [
    AppComponent,
    PublicHomeComponent,
    PublicHeaderComponent,
    PublicFooterComponent,
    AdminLoginComponent,
    AdminHeaderComponent,
    AdminHomeComponent,
    AdminChangePasswordComponent,
    ManageCategoryComponent,
    ViewPartnerComponent,
    ViewBlockedPartnerComponent,
    ViewAllOrdersComponent,
    ViewTodayOrdersComponent,
    UserRegistrationComponent,
    UserLoginComponent,
    ViewCartComponent,
    UserHomeComponent,
    UserHeaderComponent,
    UserMyOrdersComponent,
    UserChangePasswordComponent,
    PartnerRegistrationComponent,
    PartnerLoginComponent,
    PartnerHomeComponent,
    PartnerHeaderComponent,
    PartnerChangePasswordComponent,
    PartnerManageItemComponent,
    PartnerDeliveryBoyComponent,
    PartnerConfirmedOrdersComponent,
    PartnerPendindOrdersComponent,
    SearchItemComponent,
    ThankYouComponent,
    SearchPartnerComponent,
    SearchPartnerDetailsComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {
}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewTodayOrdersComponent } from './view-today-orders.component';

describe('ViewTodayOrdersComponent', () => {
  let component: ViewTodayOrdersComponent;
  let fixture: ComponentFixture<ViewTodayOrdersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewTodayOrdersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewTodayOrdersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

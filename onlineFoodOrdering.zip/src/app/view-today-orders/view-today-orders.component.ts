import {Component, OnInit} from '@angular/core';
import {AdminService} from '../admin.service';

@Component({
  selector: 'app-view-today-orders',
  templateUrl: './view-today-orders.component.html',
  styleUrls: ['./view-today-orders.component.css']
})
export class ViewTodayOrdersComponent implements OnInit {
  TodaysOrders: any = '';

  constructor(private adminservice: AdminService) {
  }

  ngOnInit(): void {
    // VIEW ALL ORDERS
    this.GetAllTodaysOrders();
  }

  // VIEW ALL ORDERS
  GetAllTodaysOrders() {
    let formData = new FormData();
    formData.append('action', 'getTodaysOrders');
    this.adminservice.OrdersAction(formData).subscribe((res: any) => {
      console.log(res);
      this.TodaysOrders = res;
    });
  }

}

import {Component, OnInit} from '@angular/core';
import {AdminService} from '../admin.service';

@Component({
  selector: 'app-admin-change-password',
  templateUrl: './admin-change-password.component.html',
  styleUrls: ['./admin-change-password.component.css']
})
export class AdminChangePasswordComponent implements OnInit {
  passwordvalidation: boolean = true;

  constructor(private admin_service: AdminService) {
  }

  ngOnInit(): void {
  }

  // COMPARE PASSWORD
  comparePassowrds(password: any, confirmpassword: any) {
    if (password.value !== confirmpassword.value) {
      this.passwordvalidation = false;
    } else {
      this.passwordvalidation = true;
    }
  }

  // UPDATE PASSWORD
  ChangePasswordAction(data: any) {
    // console.log(data);
    this.admin_service.ChangePassword(data).subscribe((res: any) => {
      // console.log(res);
      if (res.status == 'passwordInvalid') {
        alert('Invalid Old Password');
      } else {
        alert('Password Updated');
        (document.getElementById('passwordForm') as HTMLFormElement).reset();
      }
    });
  }

}

import {Component, OnInit} from '@angular/core';
import {UserService} from '../user.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-user-header',
  templateUrl: './user-header.component.html',
  styleUrls: ['./user-header.component.css']
})
export class UserHeaderComponent implements OnInit {
 UserName: string;

  constructor(
    private user_service: UserService,
    private router: Router,
  ) {
  }

  ngOnInit(): void {
    // SESSION
    this.CheckUserSession();

    // SCROLL TO TOP
    this.ScrollToTop();
  }

  // SCROLL TO TOP
  ScrollToTop() {
    document.documentElement.scrollTop = 0;
  }

  // SESSION
  CheckUserSession() {
    this.user_service.UserSession().subscribe((res: any) => {
      // console.log(res);

      if (res.status == 'sessionFailed') {
        this.router.navigateByUrl('user-login');
      } else {
        this.UserName = res.status;
      }
    });
  }

  // LOGOUT
  UserLogout() {
    this.user_service.UserLogout().subscribe((res: any) => {
      // console.log(res);

      if (res.status == 'userLogout') {
        this.router.navigateByUrl('user-login');
      }
    });
  }

}

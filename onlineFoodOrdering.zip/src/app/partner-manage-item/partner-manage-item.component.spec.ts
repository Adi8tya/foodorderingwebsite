import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PartnerManageItemComponent } from './partner-manage-item.component';

describe('PartnerManageItemComponent', () => {
  let component: PartnerManageItemComponent;
  let fixture: ComponentFixture<PartnerManageItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PartnerManageItemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PartnerManageItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

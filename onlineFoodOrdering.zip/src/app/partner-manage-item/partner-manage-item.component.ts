import {Component, OnInit} from '@angular/core';
import {PartnerService} from '../partner.service';

@Component({
  selector: 'app-partner-manage-item',
  templateUrl: './partner-manage-item.component.html',
  styleUrls: ['./partner-manage-item.component.css']
})
export class PartnerManageItemComponent implements OnInit {
  AllCategories: any = '';
  checkValues: any = [];
  ItemPhoto: any = '';
  MyItems: any = '';
  URL = 'http://localhost:3000/';

  // MODAL
  _ItemID: any = '';
  _CategoryID: any = '';
  _ItemName: any = '';
  _Photo: any = '';
  _FilePath: any = '';
  _Price: any = '';
  _Description: any = '';

  constructor(
    private partner_service: PartnerService,
  ) {
  }

  ngOnInit(): void {
    // GET CATEGORY
    this.GetAllCategory();

    // VIEW
    this.ViewItem();
  }

  // UPDATE
  UpdateItem(data: any) {
    // console.log(data);
    let formData = new FormData();
    formData.append('action', 'update');
    formData.append('ItemOBJ', JSON.stringify(data));
    formData.append('photo', this.ItemPhoto);

    this.partner_service.ManageItem(formData).subscribe((res: any) => {
      // console.log(res);
      if (res.status == 'itemUpdated') {
        alert('Item Updated Successfully.');
        // (document.getElementById('photoEdit') as HTMLFormElement).();
        // VIEW
        // docu
        this.ViewItem();
      }
    });
  }

  // MODAL POP UP
  ShowModal(data: any) {
    // console.log(data);
    this._ItemID = data.itemid;
    this._CategoryID = data.categoryid;
    this._ItemName = data.itemname;
    this._Photo = data.photo;
    this._FilePath = this.URL + this._Photo;
    this._Price = data.price;
    this._Description = data.description;
  }

  // VIEW
  ViewItem() {
    let formData = new FormData();
    formData.append('action', 'view');

    this.partner_service.ManageItem(formData).subscribe((res: any) => {
      // console.log(res);
      this.MyItems = res;
    });
  }

  // DELETE
  Delete(id: any) {
    if (confirm('Are you sure to Delete ?')) {
      // console.log(id);
      let formData = new FormData();
      formData.append('action', 'delete');
      formData.append('ItemID', id);

      this.partner_service.ManageItem(formData).subscribe((res: any) => {
        // console.log(res);
        if (res.status == 'itemDeleted') {
          alert('Item Deleted.');
          // VIEW
          this.ViewItem();
        }
      });
    }
  }

  // ADD
  AddItem(data: any) {
    // console.log(data);
    let formData = new FormData();
    formData.append('action', 'add');
    formData.append('ItemOBJ', JSON.stringify(data));
    formData.append('Days', this.checkValues);
    // formData.append('Days', JSON.stringify(this.checkValues));
    formData.append('photo', this.ItemPhoto);

    this.partner_service.ManageItem(formData).subscribe((res: any) => {
      // console.log(res);
      if (res.status == 'itemExist') {
        alert('This item already exist.');
      } else {
        alert('New Item Added Successfully.');
        (document.getElementById('AddItem') as HTMLFormElement).reset();
        // VIEW
        this.ViewItem();
        this.checkValues = [];
      }
    });
  }

  // PHOTO
  SavePhoto(e: any) {
    this.ItemPhoto = e.target.files[0];
  }

  // CHECKED AREAS
  getchkvalue(ob: any) {
    // console.log(ob.target.value);
    if (ob.target.checked) {
      let va = ob.target.value;
      // let va = ob.target.value.toString();
      this.checkValues.push(va);
    } else {
      let index = this.checkValues.indexOf(ob.target.value);
      // let index = this.checkValues.indexOf(ob.target.value.toString());
      this.checkValues.splice(index, 1);
    }
    // console.log(this.checkValues);
  }

  // GET CATEGORY
  GetAllCategory() {
    let formData = new FormData();
    formData.append('action', 'getcategory');

    this.partner_service.ManageItem(formData).subscribe((res: any) => {
      // console.log(res);
      this.AllCategories = res;
    });
  }

}

import {Component, OnInit} from '@angular/core';
import {PartnerService} from '../partner.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-partner-login',
  templateUrl: './partner-login.component.html',
  styleUrls: ['./partner-login.component.css']
})
export class PartnerLoginComponent implements OnInit {
  Response: any = '';

  constructor(
    private partner_service: PartnerService,
    private router: Router,
  ) {
  }

  ngOnInit(): void {
  }

  // LOGIN
  loginAction(formTextData: any) {
    // console.log(formTextData);

    this.partner_service.PartnerLogin(formTextData).subscribe((res: any) => {
      // console.log(res);
      this.Response = res.serverresponse;

      setTimeout(() => {
        this.Response = '';
      }, 2000);

      if (this.Response == 'loginSuccess') {
        (document.getElementById('loginForm') as HTMLFormElement).reset();
        setTimeout(() => {
          this.router.navigateByUrl('partner-home');
        }, 2000);
      }
    });
  }

}

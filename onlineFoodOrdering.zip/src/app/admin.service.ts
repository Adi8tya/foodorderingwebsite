import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  URL = 'http://localhost:3000/admin';

  constructor(private http: HttpClient) {
  }

  // ORDER
  OrdersAction(data:any){
    return this.http.post(this.URL + '/manageorder', data);
  }

  // PARTNER
  PartnerAction(data:any){
    return this.http.post(this.URL + '/managepartner', data);
  }

  // CATEGORY
  CategoryAction(data:any){
    return this.http.post(this.URL + '/managecategory', data);
  }

  // CHANGE PASSWORD
  ChangePassword(data:any){
    return this.http.post(this.URL + '/adminchangepassword', data);
  }

  // LOGOUT
  Logout() {
    return this.http.get(this.URL + '/adminlogout');
  }

  // SESSION
  Session() {
    return this.http.get(this.URL + '/adminsession');
  }

  // LOGIN
  AdminLogin(formTextData: any) {
    return this.http.post(this.URL + '/adminlogin', formTextData);
  }
}

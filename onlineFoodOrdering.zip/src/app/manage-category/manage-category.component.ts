import {Component, OnInit} from '@angular/core';
import {AdminService} from '../admin.service';

@Component({
  selector: 'app-manage-category',
  templateUrl: './manage-category.component.html',
  styleUrls: ['./manage-category.component.css']
})
export class ManageCategoryComponent implements OnInit {
  AllCategories: any = '';

  // MODAL
  _categoryid: any = '';
  _categoryname: any = '';
  _categorydescription: any = '';

  constructor(private adminservice: AdminService) {
  }

  ngOnInit(): void {
    // VIEW CATEGORY
    this.GetCategory();
  }

  // UPDATE ACTION
  updateCategory(formTextData: any) {
    // console.log(formTextData);
    let formData = new FormData();
    formData.append('categoryOBJ', JSON.stringify(formTextData));
    formData.append('action', 'update');

    this.adminservice.CategoryAction(formData).subscribe((res: any) => {
      // console.log(res);
      if (res.status == 'categoryUpdated') {
        alert('Category Updated.');
        // VIEW CATEGORY
        this.GetCategory();
      }
    });
  }

  // SHOW UPDATE MODAL
  showUpdateCategory(data: any) {
    // console.log(data);
    this._categoryid = data.categoryid;
    this._categoryname = data.categoryname;
    this._categorydescription = data.description;
  }

  // DELETE
  deleteCategory(id: any) {
    // console.log(id);
    let formData = new FormData();
    formData.append('CatID', JSON.stringify(id));
    formData.append('action', 'delete');

    this.adminservice.CategoryAction(formData).subscribe((res: any) => {
      // console.log(res);
      if (res.status == 'categoryDeleted') {
        alert('Category Deleted.');
        // VIEW CATEGORY
        this.GetCategory();
      }
    });
  }

  // VIEW
  GetCategory() {
    let formData = new FormData();
    formData.append('action', 'view');

    this.adminservice.CategoryAction(formData).subscribe((res: any) => {
      // console.log(res);
      this.AllCategories = res;
    });
  }

  // ADD
  AddAction(data: any) {
    // console.log(data);
    let formData = new FormData();
    formData.append('categoryOBJ', JSON.stringify(data));
    formData.append('action', 'add');

    this.adminservice.CategoryAction(formData).subscribe((res: any) => {
      // console.log(res);
      if (res.status == 'categoryAdded') {
        alert('New Category Added.');
        (document.getElementById('CatForm') as HTMLFormElement).reset();
        // VIEW CATEGORY
        this.GetCategory();
      }
    });
  }

}

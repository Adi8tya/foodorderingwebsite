import {Component, OnInit} from '@angular/core';
import {UserService} from '../user.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {
  Response: any = '';

  constructor(
    private user_service: UserService,
    private router: Router,
  ) {
  }

  ngOnInit(): void {
  }

  // LOGIN
  loginAction(formTextData: any) {
    // console.log(formTextData);

    this.user_service.UserLogin(formTextData).subscribe((res: any) => {
      // console.log(res);
      this.Response = res.status;

      setTimeout(() => {
        this.Response = '';
      }, 2000);

      if (this.Response == 'loginSuccess') {
        (document.getElementById('loginForm') as HTMLFormElement).reset();
        setTimeout(() => {
          this.router.navigateByUrl('user-home');
        }, 2000);
      }
    });
  }

}

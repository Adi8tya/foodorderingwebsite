import {Component, OnInit} from '@angular/core';
import {PartnerService} from '../partner.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-partner-registration',
  templateUrl: './partner-registration.component.html',
  styleUrls: ['./partner-registration.component.css']
})
export class PartnerRegistrationComponent implements OnInit {
  Photo: any = '';
  Response: any = '';

  constructor(
    private partner_service: PartnerService,
    private router: Router,
  ) {
  }

  ngOnInit(): void {
  }

  // REGISTER
  signupAction(formTextData: any) {
    // console.log(formTextData);
    let formData = new FormData();
    for (let i in formTextData) {
      formData.append(i, formTextData[i]);
    }
    formData.append('photo', this.Photo);

    this.partner_service.PartnerRegister(formData).subscribe((res: any) => {
      // console.log(res);
      this.Response = res.status;

      setTimeout(() => {
        this.Response = '';
      }, 2000);

      if (res.status == 'registerSuccess') {
        (document.getElementById('registerForm') as HTMLFormElement).reset();
        setTimeout(() => {
          this.router.navigateByUrl('partner-login');
        }, 2000);
      }
    });
  }

  // PHOTO
  SavePhoto(e: any) {
    this.Photo = e.target.files[0];
    // console.log(this.Photo);
  }

}

import {Component, OnInit} from '@angular/core';
import {UserService} from '../user.service';

@Component({
  selector: 'app-user-change-password',
  templateUrl: './user-change-password.component.html',
  styleUrls: ['./user-change-password.component.css']
})
export class UserChangePasswordComponent implements OnInit {
  passwordvalidation: boolean = true;

  constructor(private user_service: UserService) {
  }

  ngOnInit(): void {
  }

  // COMPARE PASSWORD
  comparePassowrds(password: any, confirmpassword: any) {
    if (password.value !== confirmpassword.value) {
      this.passwordvalidation = false;
    } else {
      this.passwordvalidation = true;
    }
  }

  // UPDATE PASSWORD
  ChangePasswordAction(data: any) {
    // console.log(data);
    this.user_service.ChangePassword(data).subscribe((res: any) => {
      // console.log(res);
      if (res.status == 'passwordInvalid') {
        alert('Invalid Old Password');
      } else {
        alert('Password Updated');
        (document.getElementById('userPasswordForm') as HTMLFormElement).reset();
      }
    });
  }

}

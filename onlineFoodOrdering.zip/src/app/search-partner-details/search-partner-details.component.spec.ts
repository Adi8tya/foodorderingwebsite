import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchPartnerDetailsComponent } from './search-partner-details.component';

describe('SearchPartnerDetailsComponent', () => {
  let component: SearchPartnerDetailsComponent;
  let fixture: ComponentFixture<SearchPartnerDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchPartnerDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchPartnerDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

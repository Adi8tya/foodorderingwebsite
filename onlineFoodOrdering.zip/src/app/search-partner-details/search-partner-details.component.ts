import {Component, OnInit} from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {PublicService} from '../public.service';

@Component({
  selector: 'app-search-partner-details',
  templateUrl: './search-partner-details.component.html',
  styleUrls: ['./search-partner-details.component.css']
})
export class SearchPartnerDetailsComponent implements OnInit {
  partner_id: any;
  SearchedPartner: any = [];
  URL = 'http://localhost:3000/';
  photo: any;
  photo_path: any;

  constructor(private route: ActivatedRoute, private public_service: PublicService) {
  }

  ngOnInit(): void {
    this.route.queryParamMap
      .subscribe((params) => {
          // this.partner_id = {...params.keys, ...params};
          this.partner_id = {...params};
          // console.log(this.partner_id.params.p_id);
        }
      );

    // Get Partner
    this.GetPartner();
  }

  // Get Partner
  GetPartner() {
    let formData = new FormData();
    formData.append('action', 'getPartner');
    formData.append('I', this.partner_id.params.p_id);
    // formData.append('P_ID', JSON.stringify(this.partner_id.params.p_id));

    this.public_service.Search(formData).subscribe((res: any) => {
      // console.log(res);

      if (res.length > 0) {
        this.SearchedPartner = res[0];
        this.photo = res[0].photo;
        this.photo_path = this.URL + res[0].photo;
      }
    });
  }

}

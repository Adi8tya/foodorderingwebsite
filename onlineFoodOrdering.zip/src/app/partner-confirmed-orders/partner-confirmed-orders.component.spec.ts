import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PartnerConfirmedOrdersComponent } from './partner-confirmed-orders.component';

describe('PartnerConfirmedOrdersComponent', () => {
  let component: PartnerConfirmedOrdersComponent;
  let fixture: ComponentFixture<PartnerConfirmedOrdersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PartnerConfirmedOrdersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PartnerConfirmedOrdersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

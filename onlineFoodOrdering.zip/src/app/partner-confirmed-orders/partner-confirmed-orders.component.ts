declare var $: any;

import {Component, OnInit} from '@angular/core';
import {PartnerService} from '../partner.service';

@Component({
  selector: 'app-partner-confirmed-orders',
  templateUrl: './partner-confirmed-orders.component.html',
  styleUrls: ['./partner-confirmed-orders.component.css']
})

export class PartnerConfirmedOrdersComponent implements OnInit {

  AllConfirmedOrders: any = [];
  ViewDeliveryStatus: any = [];
  DeliveryBoyID: any;
  Status: any;
  OrderID: any;
  BoyID: any;

  // MODAL
  _Order_ID: any;
  _Boy_ID: any;
  _Status: any;

  constructor(private partner_service: PartnerService) {
  }

  ngOnInit(): void {
    // CONFIRMED + DISPATCHED ORDERS
    this.GetConfirmedOrders();
  }

  // UPDATE ORDER STATUS
  UpdateStatus(i: any) {
    // console.log(i);
    if (i.orderstatus == '') {
      alert('Please choose status..');
    } else {
      let formData = new FormData();
      formData.append('action', 'changestatus');
      formData.append('Order_ID', this._Order_ID);
      formData.append('Boy_ID', this._Boy_ID);
      formData.append('Status', i.orderstatus);

      this.partner_service.ConfirmOrders(formData).subscribe((res: any) => {
        // console.log(res);

        if (res.status == 'statusUpdated') {
          alert('Status updated..');
        }

        $('#statusModal').modal('hide');

        // CONFIRMED + DISPATCHED ORDERS
        this.GetConfirmedOrders();
      });
    }
  }

  // SHOW MODAL
  OpenStatusModel(data: any) {
    // console.log(data);
    this._Order_ID = data.billid;
    this._Boy_ID = data.deliveryboyid;
    this._Status = data.status;
    // console.log(this._Order_ID + ' ' + this._Boy_ID + ' ' + this._Status);
  }

  // CHECK DELIVERY STATUS
  CheckDeliveryStaus(id: any) {
    // console.log(id);
    let formData = new FormData();
    formData.append('action', 'getDeliveryBoyStatus');
    formData.append('Order_ID', id);

    this.partner_service.ConfirmOrders(formData).subscribe((res: any) => {
      console.log(res);
      if (res[0].status === 'Dispatched') {
        this.Status = 'Dispatched';
      } else if (res[0].status === 'Delivered') {
        this.Status = 'Delivered';
      } else {
        this.Status = 'Confirmed';
      }
      console.log(this.Status);

      // this.ViewDeliveryStatus = res;
      this.OrderID = res[0].orderid;
      this.BoyID = res[0].boyid;
    });
  }

  // CONFIRMED + DISPATCHED ORDERS
  GetConfirmedOrders() {
    let formData = new FormData();
    formData.append('action', 'getconfirmedorders');

    this.partner_service.ConfirmOrders(formData).subscribe((res: any) => {
      // console.log(res);
      this.AllConfirmedOrders = res;
    });
  }

}

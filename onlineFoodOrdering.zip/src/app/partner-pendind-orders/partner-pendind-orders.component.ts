import {Component, OnInit} from '@angular/core';
import {PartnerService} from '../partner.service';

@Component({
  selector: 'app-partner-pendind-orders',
  templateUrl: './partner-pendind-orders.component.html',
  styleUrls: ['./partner-pendind-orders.component.css']
})
export class PartnerPendindOrdersComponent implements OnInit {
  AllPendingOrders: any = [];
  AllDeliveryBoys: any = [];
  DeliveryBoyID: any;

  constructor(private partner_service: PartnerService) {
  }

  ngOnInit(): void {
    // PENDING ORDERS
    this.GetPendingorders();

    // DELIVERY BOY
    this.GetDeliveryBoy();
  }

  // CONFIRMED ORDER
  ApproveOrder(id: any) {
    if (this.DeliveryBoyID == undefined) {
      alert('Please select delivery boy.');
    } else {
      let formData = new FormData();
      formData.append('action', 'confirm');
      formData.append('Order_ID', id);
      formData.append('DBoy_ID', this.DeliveryBoyID);

      this.partner_service.PendingOrders(formData).subscribe((res: any) => {
        console.log(res);
        if (res.status == 'orderConfirmed') {
          alert('Order Confirmed.');

          // PENDING ORDERS
          this.GetPendingorders();
        }
      });
    }
  }


  // REJECT ORDER
  RejectOrder(id: any) {
    // console.log(id);
    // console.log(this.DeliveryBoyID);
    let formData = new FormData();
    formData.append('action', 'reject');
    formData.append('Order_ID', id);

    this.partner_service.PendingOrders(formData).subscribe((res: any) => {
      console.log(res);
      if (res.status == 'orderRejected') {
        alert('Order Rejected.');

        // PENDING ORDERS
        this.GetPendingorders();
      }
    });
  }

  // TAKE DELIVERY BOY ID
  TakeDeliveryBoyID(e: any) {
    // console.log(e.target.value);
    this.DeliveryBoyID = e.target.value;
  }

  // DELIVERY BOY
  GetDeliveryBoy() {
    let formData = new FormData();
    formData.append('action', 'getDeliveryBoy');

    this.partner_service.PendingOrders(formData).subscribe((res: any) => {
      // console.log(res);
      this.AllDeliveryBoys = res;
    });
  }

  // PENDING ORDERS
  GetPendingorders() {
    let formData = new FormData();
    formData.append('action', 'getpendingorders');

    this.partner_service.PendingOrders(formData).subscribe((res: any) => {
      // console.log(res);
      this.AllPendingOrders = res;
    });
  }

}

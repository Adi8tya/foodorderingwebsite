import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PartnerPendindOrdersComponent } from './partner-pendind-orders.component';

describe('PartnerPendindOrdersComponent', () => {
  let component: PartnerPendindOrdersComponent;
  let fixture: ComponentFixture<PartnerPendindOrdersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PartnerPendindOrdersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PartnerPendindOrdersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

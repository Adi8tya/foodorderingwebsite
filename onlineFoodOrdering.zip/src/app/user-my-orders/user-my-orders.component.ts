import {Component, OnInit} from '@angular/core';
import {UserService} from '../user.service';

@Component({
  selector: 'app-user-my-orders',
  templateUrl: './user-my-orders.component.html',
  styleUrls: ['./user-my-orders.component.css']
})
export class UserMyOrdersComponent implements OnInit {
  UserOrders: any = [];
  // UserOrders: any = '';

  constructor(
    private user_service: UserService,
  ) {
  }

  ngOnInit(): void {
    // VIEW ORDERS
    this.MyOrders();
  }

  // VIEW ORDERS
  MyOrders() {
    let formData = new FormData();
    formData.append('action', 'getmyorders');

    this.user_service.MyOrders(formData).subscribe((res: any) => {
      console.log(res);
      this.UserOrders = res;
    });
  }

}

import {Component, OnInit} from '@angular/core';
import {AdminService} from '../admin.service';

@Component({
  selector: 'app-view-all-orders',
  templateUrl: './view-all-orders.component.html',
  styleUrls: ['./view-all-orders.component.css']
})
export class ViewAllOrdersComponent implements OnInit {
  AllOrders: any = '';
  AllOrdersDetails: any = '';

  constructor(private adminservice: AdminService) {
  }

  ngOnInit(): void {
    // VIEW ALL ORDERS
    this.GetAllOrders();
  }

  // VIEW ALL ORDERS + ORDERS DETAILS
  GetAllOrders() {
    let formData = new FormData();
    formData.append('action', 'getAllOrders');
    this.adminservice.OrdersAction(formData).subscribe((res: any) => {
      console.log(res);
      this.AllOrders = res;
    });
  }

}

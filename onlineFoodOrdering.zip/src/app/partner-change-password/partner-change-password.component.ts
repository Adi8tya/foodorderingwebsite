import {Component, OnInit} from '@angular/core';
import {PartnerService} from '../partner.service';

@Component({
  selector: 'app-partner-change-password',
  templateUrl: './partner-change-password.component.html',
  styleUrls: ['./partner-change-password.component.css']
})
export class PartnerChangePasswordComponent implements OnInit {
  passwordvalidation: boolean = true;

  constructor(
    private partner_service: PartnerService,
  ) {
  }

  ngOnInit(): void {
  }

  // COMPARE PASSWORD
  comparePassowrds(password: any, confirmpassword: any) {
    if (password.value !== confirmpassword.value) {
      this.passwordvalidation = false;
    } else {
      this.passwordvalidation = true;
    }
  }

  // UPDATE PASSWORD
  ChangePasswordAction(data: any) {
    // console.log(data);
    this.partner_service.ChangePassword(data).subscribe((res: any) => {
      // console.log(res);
      if (res.status == 'passwordInvalid') {
        alert('Invalid Old Password');
      } else {
        alert('Password Updated');
        (document.getElementById('partnerPasswordForm') as HTMLFormElement).reset();
      }
    });
  }

}

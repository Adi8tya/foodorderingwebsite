import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';

export interface ICustomWindow extends Window {
  __custom_global_stuff: string;
}

function getWindow(): any {
  return window;
}

@Injectable({
  providedIn: 'root'
})

export class UserService {
  URL = 'http://localhost:3000/users';

  get nativeWindow(): ICustomWindow {
    return getWindow();
  }

  constructor(private http: HttpClient) {
  }

  // REMOVE SELECTED PRODUCT
  RemoveSelectedProductFromCart(data: any) {
    return this.http.post(this.URL + '/Add-To-Cart-Selected-Product', data);
  }

  // +,- Button Working
  updateSelectedProductQuantity(data: any) {
    return this.http.post(this.URL + '/Add-To-Cart-Selected-Product', data);
  }

  // GET PRODUCTS In CART FROM SERVER
  GetProductsInCartFromServer() {
    return this.http.get(this.URL + '/Get-Cart-Products-From-Server');
  }

  // ADD TO CART SELECTED PRODUCT
  AddToCartSelectedProduct(data: any) {
    return this.http.post(this.URL + '/Add-To-Cart-Selected-Product', data);
  }

  // MY ORDERS
  MyOrders(data: any) {
    return this.http.post(this.URL + '/userorders', data);
  }

  // CHANGE PASSWORD
  ChangePassword(data: any) {
    return this.http.post(this.URL + '/userchangepassword', data);
  }

  // SESSION
  UserSession() {
    return this.http.get(this.URL + '/usersession');
  }

  // LOGOUT
  UserLogout() {
    return this.http.get(this.URL + '/userlogout');
  }

  // LOGIN
  UserLogin(formTextData: any) {
    return this.http.post(this.URL + '/userlogin', formTextData);
  }

  // REGISTER
  UserRegister(formTextData: any) {
    return this.http.post(this.URL + '/usersignup', formTextData);
  }
}

import {Component, OnInit} from '@angular/core';
import {AdminService} from '../admin.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-admin-header',
  templateUrl: './admin-header.component.html',
  styleUrls: ['./admin-header.component.css']
})
export class AdminHeaderComponent implements OnInit {
  AdminName: string;

  constructor(
    private adminservice: AdminService,
    private router: Router
  ) {
  }

  ngOnInit(): void {
    // SESSION
    this.checkAdminSession();

    // SCROLL TO TOP
    this.ScrollToTop();
  }

  // LOGOUT
  adminLogout() {
    this.adminservice.Logout().subscribe((res: any) => {
      // console.log(res);

      if (res.status == 'adminLogout') {
        this.router.navigateByUrl('admin-login');
      }
    });
  }

  // SESSION
  checkAdminSession() {
    this.adminservice.Session().subscribe((res: any) => {
      // console.log(res);

      if (res.status == 'sessionFailed') {
        this.router.navigateByUrl('admin-login');
      } else {
        this.AdminName = res.status;
      }
    });
  }

  // SCROLL TO TOP
  ScrollToTop() {
    document.documentElement.scrollTop = 0;
  }

}

import {Component, OnInit} from '@angular/core';
import {PublicService} from '../public.service';
import {UserService} from '../user.service';

@Component({
  selector: 'app-search-item',
  templateUrl: './search-item.component.html',
  styleUrls: ['./search-item.component.css']
})
export class SearchItemComponent implements OnInit {
  SearchedItems: any = [];
  Response: any = '';
  URL = 'http://localhost:3000/';

  constructor(
    private public_service: PublicService,
    private user_Service: UserService,
  ) {
  }

  ngOnInit(): void {
  }

  // ADD TO CART BUTTON
  addToCart(productOBJ: any) {
    // console.log(productOBJ);

    let formdata = new FormData();
    formdata.append('product_obj', JSON.stringify(productOBJ));
    formdata.append('action', 'add');

    this.user_Service.AddToCartSelectedProduct(formdata).subscribe((res: any) => {
      // console.log(res);
      if (res.status == 'duplicate') {
        alert('This product is already exist in your cart.');
        // this.router.navigateByUrl('shoppingCart');
      } else {
        alert('Product Added To Cart.');
        (<HTMLSpanElement> document.getElementById('user-cart-count')).innerHTML = res;
      }
    });
  }

  // SEARCH ITEM from database..
  SearchItem(data: any) {
    // console.log(data);
    let formData = new FormData();
    formData.append('action', 'searchItem');
    formData.append('I', JSON.stringify(data));

    this.public_service.Search(formData).subscribe((res: any) => {
      // console.log(res);

      if (res.length > 0) {
        this.SearchedItems = res;
      } else {
        this.SearchedItems = '';
        this.Response = 'notfound';
        setTimeout(() => {
          this.Response = '';
        }, 1000);
      }
    });
  }

}

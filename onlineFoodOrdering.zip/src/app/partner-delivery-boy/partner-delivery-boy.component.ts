import {Component, OnInit} from '@angular/core';
import {PartnerService} from '../partner.service';

@Component({
  selector: 'app-partner-delivery-boy',
  templateUrl: './partner-delivery-boy.component.html',
  styleUrls: ['./partner-delivery-boy.component.css']
})
export class PartnerDeliveryBoyComponent implements OnInit {
  DBoyPhoto: any = '';
  DeliveryBoys: any = '';
  URL = 'http://localhost:3000/';

  // MODAL
  _ID: any = '';
  _Name: any = '';
  _Mobile: any = '';
  _Address: any = '';
  _Photo: any = '';
  _FilePath: any = '';
  _StartTime: any = '';
  _EndTime: any = '';

  constructor(
    private partner_service: PartnerService
  ) {
  }

  ngOnInit(): void {
    // VIEW
    this.ViewDeliveryBoy();
  }

  // UPDATED
  UpdateDBoy(data: any) {
    // console.log(data);
    let formData = new FormData();
    formData.append('action', 'update');
    formData.append('photo', this.DBoyPhoto);
    formData.append('DBoyOBJ', JSON.stringify(data));

    this.partner_service.ManageDeliveryBoy(formData).subscribe((res: any) => {
      console.log(res);
      if (res.status == 'DBoyUpdated') {
        alert('Delivery Boy Updated.');
        this._FilePath = '';
        (document.getElementById('editDBoyForm') as HTMLFormElement).reset();
        // VIEW
        this.ViewDeliveryBoy();
      }
    });
  }

  // SHOW MODAL DATA
  Update(data: any) {
    // console.log(data);
    this._ID = data.deliveryid;
    this._Name = data.name;
    this._Mobile = data.mobileno;
    this._Address = data.address;
    this._Photo = data.photo;
    this._FilePath = this.URL + this._Photo;
    this._StartTime = data.starttime;
    this._EndTime = data.endtime;
  }

  // DELETE
  Delete(id: any) {
    // console.log(id);
    if (confirm('Are you sure to Delete ?')) {
      let formData = new FormData();
      formData.append('action', 'delete');
      formData.append('ID', id);

      this.partner_service.ManageDeliveryBoy(formData).subscribe((res: any) => {
        // console.log(res);
        if (res.status == 'DBoyDeleted') {
          alert('Deleted Successfully.');
          // VIEW
          this.ViewDeliveryBoy();
        }
      });
    }
  }

  // VIEW
  ViewDeliveryBoy() {
    let formData = new FormData();
    formData.append('action', 'view');

    this.partner_service.ManageDeliveryBoy(formData).subscribe((res: any) => {
      // console.log(res);
      this.DeliveryBoys = res;
    });
  }

  // ADD
  AddDBoy(data: any) {
    // console.log(data);
    let formData = new FormData();
    formData.append('action', 'add');
    formData.append('photo', this.DBoyPhoto);
    formData.append('DBoyOBJ', JSON.stringify(data));

    this.partner_service.ManageDeliveryBoy(formData).subscribe((res: any) => {
      // console.log(res);
      if (res.status == 'DBoyAdded') {
        alert('New Delivery Boy Added.');
        (document.getElementById('DeliveryForm') as HTMLFormElement).reset();
        // VIEW
        this.ViewDeliveryBoy();
      }
    });
  }

  SavePhoto(e: any) {
    // console.log(e.target.files[0]);
    this.DBoyPhoto = e.target.files[0];
  }

}

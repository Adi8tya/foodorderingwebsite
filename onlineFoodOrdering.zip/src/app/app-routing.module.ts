import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {PublicHomeComponent} from './public-home/public-home.component';
import {AdminLoginComponent} from './admin-login/admin-login.component';
import {AdminHomeComponent} from './admin-home/admin-home.component';
import {AdminChangePasswordComponent} from './admin-change-password/admin-change-password.component';
import {ManageCategoryComponent} from './manage-category/manage-category.component';
import {ViewPartnerComponent} from './view-partner/view-partner.component';
import {ViewBlockedPartnerComponent} from './view-blocked-partner/view-blocked-partner.component';
import {ViewAllOrdersComponent} from './view-all-orders/view-all-orders.component';
import {ViewTodayOrdersComponent} from './view-today-orders/view-today-orders.component';
import {UserRegistrationComponent} from './user-registration/user-registration.component';
import {UserLoginComponent} from './user-login/user-login.component';
import {ViewCartComponent} from './view-cart/view-cart.component';
import {UserHomeComponent} from './user-home/user-home.component';
import {UserMyOrdersComponent} from './user-my-orders/user-my-orders.component';
import {UserChangePasswordComponent} from './user-change-password/user-change-password.component';
import {PartnerLoginComponent} from './partner-login/partner-login.component';
import {PartnerRegistrationComponent} from './partner-registration/partner-registration.component';
import {PartnerHomeComponent} from './partner-home/partner-home.component';
import {PartnerChangePasswordComponent} from './partner-change-password/partner-change-password.component';
import {PartnerManageItemComponent} from './partner-manage-item/partner-manage-item.component';
import {PartnerDeliveryBoyComponent} from './partner-delivery-boy/partner-delivery-boy.component';
import {PartnerPendindOrdersComponent} from './partner-pendind-orders/partner-pendind-orders.component';
import {PartnerConfirmedOrdersComponent} from './partner-confirmed-orders/partner-confirmed-orders.component';
import {SearchItemComponent} from './search-item/search-item.component';
import {ThankYouComponent} from './thank-you/thank-you.component';
import {SearchPartnerComponent} from './search-partner/search-partner.component';
import {SearchPartnerDetailsComponent} from './search-partner-details/search-partner-details.component';

const routes: Routes = [
  // --------------------------------------------------------------------------
  // PUBLIC
  {path: '', component: PublicHomeComponent},
  {path: 'search-item', component: SearchItemComponent},
  {path: 'search-partner', component: SearchPartnerComponent},
  {path: 'search-partner-details', component: SearchPartnerDetailsComponent},
  // {path: 'about', component: A},
  // {path: 'contact', component: C},
  {path: 'view-cart', component: ViewCartComponent},
  {path: 'thank-you', component: ThankYouComponent},
  // --------------------------------------------------------------------------
  // ADMIN
  {path: 'admin-login', component: AdminLoginComponent},
  {path: 'admin-home', component: AdminHomeComponent},
  {path: 'admin-change-password', component: AdminChangePasswordComponent},
  {path: 'admin-manage-category', component: ManageCategoryComponent},
  {path: 'view-partner', component: ViewPartnerComponent},
  {path: 'view-blocked-partner', component: ViewBlockedPartnerComponent},
  {path: 'view-all-orders', component: ViewAllOrdersComponent},
  {path: 'view-today-orders', component: ViewTodayOrdersComponent},
  // --------------------------------------------------------------------------
  // USER
  {path: 'user-register', component: UserRegistrationComponent},
  {path: 'user-login', component: UserLoginComponent},
  {path: 'user-home', component: UserHomeComponent},
  {path: 'user-change-password', component: UserChangePasswordComponent},
  {path: 'my-orders', component: UserMyOrdersComponent},
  // --------------------------------------------------------------------------
  // PARTNER
  {path: 'partner-register', component: PartnerRegistrationComponent},
  {path: 'partner-login', component: PartnerLoginComponent},
  {path: 'partner-home', component: PartnerHomeComponent},
  {path: 'partner-change-password', component: PartnerChangePasswordComponent},
  {path: 'partner-add-item', component: PartnerManageItemComponent},
  {path: 'partner-view-item', component: PartnerManageItemComponent},
  {path: 'partner-delivery_boy', component: PartnerDeliveryBoyComponent},
  {path: 'partner-pending-orders', component: PartnerPendindOrdersComponent},
  {path: 'partner-confirmed-orders', component: PartnerConfirmedOrdersComponent},
  // --------------------------------------------------------------------------

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
}

import {Component, OnInit} from '@angular/core';
import {AdminService} from '../admin.service';

@Component({
  selector: 'app-view-blocked-partner',
  templateUrl: './view-blocked-partner.component.html',
  styleUrls: ['./view-blocked-partner.component.css']
})
export class ViewBlockedPartnerComponent implements OnInit {
  AllBlockedPartners: any = '';

  constructor(private adminservice: AdminService) {
  }

  ngOnInit(): void {
    // VIEW BLOCKED PARTNER
    this.GetAllBlockedPartners();
  }

  UnblockPartner(id: any, status: any) {
    // console.log(id);
    // console.log(status);
    if (confirm('Are you sure you want to Unblock ?')) {
      let formData = new FormData();
      formData.append('action', 'partner');
      formData.append('partnerid', id);
      formData.append('status', status);

      this.adminservice.PartnerAction(formData).subscribe((res: any) => {
        console.log(res);
        alert('Partner Activated.');
        this.GetAllBlockedPartners();
      });
    }
  }

  // VIEW BLOCKED PARTNER
  GetAllBlockedPartners() {
    let formData = new FormData();
    formData.append('action', 'getBlockedPartner');

    this.adminservice.PartnerAction(formData).subscribe((res: any) => {
      // console.log(res);
      this.AllBlockedPartners = res;
    });
  }

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewBlockedPartnerComponent } from './view-blocked-partner.component';

describe('ViewBlockedPartnerComponent', () => {
  let component: ViewBlockedPartnerComponent;
  let fixture: ComponentFixture<ViewBlockedPartnerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewBlockedPartnerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewBlockedPartnerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
